/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author SARANGO
 */
public class Proyecto4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nombre = "jose";
        String apellido = "Sarango";
        int edad = 24;
        double valor = 400.5;
       
         System.out.printf("%s %s\n\tedad:%d\n\tvalor;%.2f\n",nombre,apellido,edad,valor);
        
    }
    
}
