
package proyecto1;

import java.util.Scanner;

/**
 *
 * @author SARANGO
 */
public class ejemplo5 {

    /**
     * @param args the command line arguments
     */ 
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
                
        String nombre;
        String apellido;
        System.out.println("Ingrese valor para su nombre");
        nombre = entrada.nextLine();
        System.out.println("ingrese valor para su apellido");
        apellido = entrada.next();
        
        System.out.printf("Su nombre es: %s\nSu Apellido:%s\n",nombre,apellido);

    }

}
